#include "btree.h"
#include "constants.h"
#include <iostream>
#include <cassert>

using namespace std;


void small_test1() {
    Btree btree;
    cout << btree << endl;
    btree.insert(0);
    btree.insert(2);
    btree.insert(3);
    cout << btree << endl;
    btree.remove(0);
    cout << btree << endl;
    btree.remove(2);
    cout << btree << endl;
    btree.insert(2);
    cout << btree << endl;
    btree.insert(0);
    cout << btree << endl;
    btree.remove(2);
    cout << btree << endl;
    assert(btree.isValid());
}

void large_test() {
    Btree btree;
    btree.insert(1);
    btree.insert(2);
    btree.insert(3);
    btree.insert(4);
    btree.insert(6);
    btree.insert(8);
    btree.insert(13);
    btree.insert(15);
    btree.insert(17);
    cout << btree << endl;
    btree.insert(33);
    cout << btree << endl;
    btree.remove(13);
    cout << btree << endl;
    btree.remove(3);
    cout << btree << endl;

    btree.insert(10);
    btree.insert(7);

    cout << btree << endl;
    btree.remove(8);
    cout << btree << endl;

    btree.remove(6);
    btree.insert(18);
    btree.insert(19);
    btree.remove(17);
    btree.insert(20);
    btree.insert(34);
    cout << btree << endl;

    btree.insert(11);
    btree.insert(12);
    btree.insert(17);
    cout << btree << endl;

    btree.insert(13);
    cout << btree << endl;

    btree.remove(7);
    cout << btree << endl;
    btree.remove(2);
    cout << btree << endl;
    assert(btree.isValid());
}

int main() {
    small_test1();
    large_test();
    return 0;
}
